#include "view/kyview.h"

#include <QApplication>
#include <QLibraryInfo>
#include <QTranslator>
#include <ukui-log4qt.h>
#include "global/log.h"
#include "controller/interaction.h"
#include "view/xatom-helper.h"

int main(int argc, char *argv[])
{ 
    //添加4K 屏幕支持。
#if(QT_VERSION >= QT_VERSION_CHECK(5, 6, 0))
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QCoreApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
#else
    // do not support 4K.
#endif
     //添加9A0基于qt5.15 屏幕支持。
#if (QT_VERSION >= QT_VERSION_CHECK(5, 12, 0))
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
#endif
#if (QT_VERSION >= QT_VERSION_CHECK(5, 14, 0))
    QApplication::setHighDpiScaleFactorRoundingPolicy(Qt::HighDpiScaleFactorRoundingPolicy::PassThrough);
#endif
    QApplication a(argc, argv);

    //注册MessageHandler
//    qInstallMessageHandler(Log::msgHandler);
    initUkuiLog4qt("kylin-photo-viewer");
    //应用禁用跟随系统字号
//    qApp->setProperty("noChangeSystemFontSize",true);
//    QFont font = qApp->font();
//    font.setPointSizeF(11);
//    qApp->setFont(font);
    qApp->setWindowIcon(QIcon::fromTheme("kylin-photo-viewer", QIcon(":/res/res/kyview_logo.png")));

    //翻译
    QTranslator app_trans;
    QTranslator qt_trans;
    QString locale = QLocale::system().name();
    QString trans_path;
    if (QDir("/usr/share/kylin-photo-viewer/translations").exists()) {
        trans_path = "/usr/share/kylin-photo-viewer/translations";
    }
    else {
        trans_path = qApp->applicationDirPath() + "/translations";
    }
    QString qt_trans_path;
    qt_trans_path = QLibraryInfo::location(QLibraryInfo::TranslationsPath);// /usr/share/qt5/translations

    if(!app_trans.load("kylin-photo-viewer_" + locale + ".qm", trans_path)){
        qDebug() << "Load translation file："<< "kylin-photo-viewer_" + locale + ".qm from" << trans_path << "failed!";
    } else {
        a.installTranslator(&app_trans);
    }

    if (!qt_trans.load("qt_" + locale + ".qm", qt_trans_path)){
        qDebug() << "Load translation file："<< "qt_" + locale + ".qm from" << qt_trans_path << "failed!";
    } else {
        a.installTranslator(&qt_trans);
    }
    QTranslator app_trans_penoy;
    app_trans_penoy.load("/usr/share/libpeony-qt/libpeony-qt_"+QLocale::system().name());
    a.installTranslator(&app_trans_penoy);

    //主题框架
    KyView w(a.arguments());
    MotifWmHints hints;
    hints.flags = MWM_HINTS_FUNCTIONS|MWM_HINTS_DECORATIONS;
    hints.functions = MWM_FUNC_ALL;
    hints.decorations = MWM_DECOR_BORDER;
    XAtomHelper::getInstance()->setWindowMotifHint(w.winId(), hints);

    Interaction::getInstance()->initUiFinish();
    return a.exec();
}
