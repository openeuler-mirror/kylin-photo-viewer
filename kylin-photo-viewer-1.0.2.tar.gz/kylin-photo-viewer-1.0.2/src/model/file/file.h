#ifndef FILE_H
#define FILE_H

#include <QObject>
#include <QFileInfo>
#include <QVariant>
#include "model/processing/processing.h"
#include "global/computingtime.h"
#include "gio/gio.h"
#include <gio/gfileinfo.h>
#include "global/variable.h"


typedef MatResult MatAndFileinfo;

class File : public QObject
{
    Q_OBJECT

public:
    static MatAndFileinfo loadImage(QString path, ImreadModes modes = IMREAD_UNCHANGED);
    static bool saveImage(const Mat &mat , const QString &savepath , bool replace = true);//静态图
    static bool saveImage(QList<Mat> *list ,const int &fps, const QString &savepath , bool replace = true);//动态图
    static void deleteImage(const QString &savepath);
    static bool isSaving(const QString &path);
    static bool allSaveFinish();
    static bool canDel(QString path);//判断是否可删除

private:
    static void processStart(const QString &cmd , QStringList arguments = QStringList());
    static QProcess *m_process;//操作文件
};

#endif // FILE_H
