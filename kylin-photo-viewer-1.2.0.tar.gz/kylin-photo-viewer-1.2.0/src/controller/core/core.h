#ifndef CORE_H
#define CORE_H

#include "base.h"

#define SET_BACKGROUND_PICTURE_GSETTINGS_PATH "org.mate.background"
#define SET_BACKGROUND_PICTURE_GSETTINGS_NAME "pictureFilename"

class MyStandardItem :public QStandardItem
{
public:
    void setPath(const QString &path);
    QString getPath();
private:
    QString m_path;
};

class Core : public QObject , public NavigationStatus
{
    Q_OBJECT

Q_SIGNALS:
    void needOpenImage(QString path);//启动时打开图片
    void openFinish(QVariant var);//打开完成
    void showNavigation(QPixmap pix);//操作导航器
    void coreProgremExit();//结束进程
    void changeAlbumHighLight(QModelIndex modelIndex);//在相册中选中到所切换的图片
    void delayShow(bool isLoading);//处理图片加载缓慢问题
    void openFromAlbum();//从相册打开
    void renameResult(int code, QFileInfo newPath);//返回报错信息和新路径
    void canDelImage(bool canDelOrnot);//返回是否可删除信号
    void updateSideNum(int sideBength);//更新相册长度
    void fullScreen();//处理dbus信号-全屏
    void releaseRegion(QPoint start,QPoint end);
    void cutSaveFinish();//裁剪结束
    void returnMouseType(int type);//回传鼠标形状
    void isCutNotSave();//关闭时-正在裁剪，给前端发信号询问是否保存更改
    void sendHightlightPos(QPoint startPos,QPoint endPos);//给前端发送导航器高亮区域范围

public:
    Core();
    QString initDbus(const QStringList &arguments);//初始化Dbus模块
    void findAllImageFromDir(QString fullPath);//寻找目录下所有支持的图片
    void openImage(QString fullPath);//打开图片
    void changeImage(const int &type); //切换图片
    void changeImageFromClick(QModelIndex modelIndex); //切换图片
    void changeWidgetSize(const QSize &size);//切换窗口大小
    void changeImageShowSize(ImageShowStatus::ChangeShowSizeType type);//图片显示状态（放大缩小）
    void clickNavigation(const QPoint &point = QPoint(-1,-1));//导航器点击
    void flipImage(const Processing::FlipWay &way);//翻转处理
    void deleteImage();//删除图片
    void setAsBackground();//设置为背景图
    void openInfile();//文件夹中打开
    void changeOpenIcon(QString theme);//主题改变时切换相册打开按钮
    void saveMovieFinish(const QString &path);//异步处理完成
    void close();//关闭进程
    QStandardItemModel * getAlbumModel();//获取相册model指针
    void albumLoadFinish(QVariant var);//预览加载完成
    void toCoreChangeName(QString oldName, QString newName);//接收重命名的处理
    void toPrintImage(QPrinter *printer);//打印
    bool openFail(QString fullPath);//打开失败，判断是否为拖拽打开失败
    void cutImage();//开始裁剪，处理显示的图片
    void cutRegion(const QPoint &point);//裁剪区域
    void startChange(const QPoint &point);//起始点-裁剪
    void realsePos(const QPoint &point);//裁剪-释放鼠标
    void releaseCutChange(int type, const QPoint &point);//裁剪-释放鼠标后再次改变尺寸
    void exitCut();//退出裁剪
    void needSaveCutImage(int proportion);//保存裁剪图片
    void needSaveAsImage(QString path);//另存为
    void reloadImage(QModelIndex modelIndex);//判断是否需要加载

private:
    void initCore();//初始化核心
    Dbus *m_dbus = nullptr;//DBus模块对象
    void showImage(const QPixmap &pix);//显示图片
    void showImageOrMovie();//显示图片或动图
    void creatImage(const int &proportion = -1, bool defaultOpen = true);//生成图像，defaultOpen区分是否是打开图片，无其他操作
    void defaultImage(int proportion,int defaultProportion);//默认显示图片原则
    void operateImage(int proportion,int defaultProportion);//进行操作显示图片原则
    void processingCommand(const QStringList &cmd);//处理终端命令
    QString processingApi(const QStringList &cmd);//处理外部命令
    void processingFullscreen();
    void creatModule(const QString &path, QStringList list);//创建module
    void loadAlbum(const QString &path, QStringList list ,unsigned int page = 0 ,unsigned int maxPerPage = Variable::LOADIMAGE_NUM);//加载相册
    void navigation(const QPoint &point = QPoint(-1,-1));//导航器
    void playMovie();//播放动图的槽函数
    inline void changeImageType(QString path = "");//修改图片标签
    Mat changeMat(Mat mat);//更改当前图片
    void creatNavigation();//创建导航器图片等数据，用于节省算力
    void deleteAlbumItem(const QString &path);//删除相册中的项
    ChamgeImageType nextOrBack(const QString &oldPath,const QString &newPath);
    RenameState successOrFail(const QString &oldPath,const QString &newPath);//返回重命名结果
    QString nextImagePath(const QString & oldPath);
    QString backImagePath(const QString & oldPath);
    void setHighLight(const QString &path);
    bool coreOperateTooOften();//操作过于频繁
    void progremExit();//结束进程
    bool apiFunction();//处理api函数
    bool isSamePath(QString path);//判断打开的是不是相同路径
    QStringList diffPath(QStringList image);//判断打开的同一个路径下的图片文件夹内是否还有其他图片
    void needSave();//判断是否需要保存图片
    void processNewLoadImage();//处理--上一次图片没处理完就进行下一次操作时，更新对齐动图每一帧的操作状态
    bool m_isclose = false;
    MyStandardItem *m_item0  = nullptr;
    bool m_shouldClose = false;//可以关闭
    bool m_isApi = false;//作为API接口运行
    bool m_apiReplaceFile = false;//api替换原图
    QStringList m_apiCmd;//保存操作命令
    QTimer *m_canProcess = nullptr;//限制操作频率，降低cpu占用

    //裁剪部分
    QPoint boundingSet(QPoint point,int xMax,int yMax);//计算边界值
    void cutFinishReset();//裁剪完毕，状态重置
    void openSaveImage();//针对于裁剪和另存为，打开保存的图片
    void loadOnChange(QString path);//切换时加载--拿QModelIndex

    bool m_isCanDel = false;//判断是否可删除，默认为true
    QImage m_origCutImage;//待显示的裁剪的背景图
    QImage m_origCutImageBefore;//待显示的裁剪的背景图-原图
    bool m_isCutting = false;//正在裁剪
    QPoint m_cutBeforeStartPosition = QPoint (-1,-1);//记录起始点
    QPoint m_cutStartPostionSave = QPoint (-1,-1);//保存前一个裁剪的起始点
    QSize m_cuthightlightSize; //高亮区域大小;
    QSize m_cuthightlightSizeBefore = QSize(0,0);//高亮区域大小-上一次的
    int m_cutspaceWidth = 0;//导航栏窗口与缩略图左边缘距离
    int m_cutspaceHeight = 0;//导航栏窗口与缩略图上边缘距离
    QImage m_cutImage;//记录鼠标释放后的图像
    bool m_hasCutBox = false;//有裁剪框存在的情况
    QPoint m_startP = QPoint (-1,-1);
    QPoint m_endP = QPoint (-1,-1);
    QPoint m_backPointRelease = QPoint(-1,-1);
    bool m_isReleasePaint = false;//正在进行释放后又绘制的动作--默认为false，没有进行动作
    int m_backType = -1;//标记上一个动作的鼠标类型
    bool m_isCutSaved = false;//记录裁剪是否保存--默认为false--已完成或未开始
    QString m_paperFormat;
    QStringList m_loadedImage;//已经加载了的图片
    QStringList m_allImageList;//所有图片的路径
    int m_currentPage = 0;//存当前页，处理某些特殊情况

    bool judgeSizeIsZero(QSize size);//判断尺寸为中宽高有等于0的
    CutRegion cutRegionSelection(QPointF startPos, QSize cutSize, QPixmap nowImage);

};

#endif // CORE_H
