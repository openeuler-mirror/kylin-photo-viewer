#include "coreinteraction.h"

Interaction * Interaction::m_interaction(nullptr);

Interaction *Interaction::getInstance()
{
    if (m_interaction == nullptr) {
        m_interaction = new CoreInteraction;
    }
    return m_interaction;
}


CoreInteraction::CoreInteraction()
{
    m_canProcess = new QTimer(this);
    m_canProcess->setSingleShot(true);
}

void CoreInteraction::creatCore(const QStringList &list)
{
    if (m_isCoreInit) {
        return;//防止多次初始化核心
    }
    //开辟线程
    m_core = new Core();
    m_needStartWithOpenImagePath = m_core->initDbus(list);
    QThread *thread = new QThread();
    //绑定信号和槽
    initConnect();
    //放到新线程中
    m_core->moveToThread(thread);
    thread->start();
    m_isCoreInit = true;//防止多次初始化核心
}

void CoreInteraction::initConnect()
{
    connect(this,&CoreInteraction::coreOpenImage,m_core,&Core::findAllImageFromDir);//生成缩略图列表
    connect(this,&CoreInteraction::coreGetAlbumModel,m_core,&Core::getAlbumModel,Qt::BlockingQueuedConnection);//获取相册model指针
    connect(m_core,&Core::openFinish,this,&CoreInteraction::openFinish);//图片打开完成，将数据返回给UI层
    connect(this,&CoreInteraction::coreChangeImage,m_core,&Core::changeImage);//切换图片
    connect(this,&CoreInteraction::coreChangeWidgetSize,m_core,&Core::changeWidgetSize);//改变窗口大小
    connect(this,&CoreInteraction::coreChangeImageShowSize,m_core,&Core::changeImageShowSize);//图片显示状态（放大缩小）
    connect(m_core,&Core::showNavigation,this,&CoreInteraction::showNavigation);//显示导航器
    connect(this,&CoreInteraction::coreClickNavigation,m_core,&Core::clickNavigation);//导航器点击
    connect(this,&CoreInteraction::coreFlip,m_core,&Core::flipImage);//翻转
    connect(this,&CoreInteraction::coreDeleteImage,m_core,&Core::deleteImage);//删除图片
    connect(this,&CoreInteraction::coreSetAsBackground,m_core,&Core::setAsBackground);//设置为背景图
    connect(this,&CoreInteraction::coreOpenInfile,m_core,&Core::openInfile);//文件夹中打开
    connect(this,&CoreInteraction::coreChangeOpenIcon,m_core,&Core::changeOpenIcon);//更改主题，切换相册打开按钮图标
    connect(this,&CoreInteraction::coreClose,m_core,&Core::close);//关闭事件
    connect(m_core,&Core::coreProgremExit,this,&CoreInteraction::progremExit);//发送信号让主界面结束进程
    connect(this,&CoreInteraction::changeImageFromClick,m_core,&Core::changeImageFromClick);//点击相册事件
    connect(m_core,&Core::changeAlbumHighLight,this,&CoreInteraction::changeAlbumHighLight);//在相册中选中到所切换的图片
    connect(m_core,&Core::delayShow,this,&CoreInteraction::delayShow);//图片加载过慢，发信号给前端
    connect(m_core,&Core::openFromAlbum,this,&CoreInteraction::openFromAlbum);//点击相册按钮打开图片
    connect(this,&CoreInteraction::coreRename,m_core,&Core::toCoreChangeName);//重命名
    connect(m_core,&Core::renameResult,this,&CoreInteraction::sendRenameResult);//返回重命名结果
    connect(this,&CoreInteraction::corePrint,m_core,&Core::toPrintImage);//打印
    connect(m_core,&Core::canDelImage,this,&CoreInteraction::changeDelState);//检查是否可被删除
    connect(m_core,&Core::updateSideNum,this,&CoreInteraction::updateSideLength);//更新相册长度
    connect(m_core,&Core::fullScreen,this,&CoreInteraction::fullScreen);
    connect(this,&CoreInteraction::coreCut,m_core,&Core::cutImage);//开始裁剪，处理需要显示的图片
    connect(this,&CoreInteraction::coreCutRegion,m_core,&Core::cutRegion);//裁剪区域
    connect(this,&CoreInteraction::coreStartChange,m_core,&Core::startChange);//起始点-裁剪
    connect(this,&CoreInteraction::coreRealsePos,m_core,&Core::realsePos);//释放时-重绘裁剪框边界
    connect(m_core,&Core::releaseRegion,this,&CoreInteraction::releaseRegion);//释放时-裁剪框的起点和终点
    connect(this,&CoreInteraction::coreReleaseCutChange,m_core,&Core::releaseCutChange);//释放后-裁剪框需要再次改变尺寸的情况
    connect(this,&CoreInteraction::coreExitCut,m_core,&Core::exitCut);//退出裁剪
    connect(this,&CoreInteraction::coreNeedSaveCutImage,m_core,&Core::needSaveCutImage);//保存裁剪图片
    connect(m_core,&Core::cutSaveFinish,this,&CoreInteraction::cutSaveFinish);//裁剪结束
    connect(this,&CoreInteraction::coreNeedSaveas,m_core,&Core::needSaveAsImage);//图片另存为
    connect(m_core,&Core::returnMouseType,this,&CoreInteraction::returnMouseShape);//回传鼠标形状
    connect(m_core,&Core::isCutNotSave,this,&CoreInteraction::isCutNotSave);//正在裁剪还未保存就要关闭
    connect(this,&CoreInteraction::coreReloadImage,m_core,&Core::reloadImage);//将当前页的item传给后端
    connect(m_core,&Core::sendHightlightPos,this,&CoreInteraction::sendHightlightPos);//回传导航栏高亮区域位置

}

bool CoreInteraction::coreOperateTooOften()
{
    if (m_canProcess->isActive()) {
        return true;
    }
    m_canProcess->start(Variable::REFRESH_RATE);//刷新间隔
    return false;
}

void CoreInteraction::initUiFinish()
{
    Q_EMIT startWithOpenImage(m_needStartWithOpenImagePath);
}

void CoreInteraction::openImage(const QString &path)
{
    Q_EMIT coreOpenImage(path);
}

void CoreInteraction::changeImage(const int &type)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeImage(type);
}

void CoreInteraction::nextImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeImage(Enums::NEXT_IMAGE);
}

void CoreInteraction::backImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeImage(Enums::BACK_IMAGE);
}

void CoreInteraction::changeWidgetSize(const QSize &size)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeWidgetSize(size);
}

void CoreInteraction::watchBigImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeImageShowSize(ImageShowStatus::BIG);
}

void CoreInteraction::watchSmallImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeImageShowSize(ImageShowStatus::SMALL);
}

void CoreInteraction::watchOriginalImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeImageShowSize(ImageShowStatus::ORIGIN);
}

void CoreInteraction::watchAutoImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeImageShowSize(ImageShowStatus::AUTO);
}

void CoreInteraction::clickNavigation(const QPoint &point)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreClickNavigation(point);
}

void CoreInteraction::rotate(const bool &clockwise)
{
    if (coreOperateTooOften()) {
        return;
    }
    if (clockwise) {
        Q_EMIT coreFlip(Processing::clockwise);
    } else {
        Q_EMIT coreFlip(Processing::counterclockwise);
    }
}

void CoreInteraction::flipH()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreFlip(Processing::horizontal);
}

void CoreInteraction::flipV()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreFlip(Processing::vertical);
}

void CoreInteraction::deleteImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreDeleteImage();
}

void CoreInteraction::setAsBackground()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreSetAsBackground();
}

void CoreInteraction::openImageInfile()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreOpenInfile();
}

void CoreInteraction::changeOpenIcon(QString theme)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreChangeOpenIcon(theme);
}

void CoreInteraction::close()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreClose();
}

QStandardItemModel *CoreInteraction::getAlbumModel()
{
    return coreGetAlbumModel();
}

void CoreInteraction::reName(QString oldPath, QString newPath)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreRename(oldPath,newPath);
}

void CoreInteraction::printImage(QPrinter *printer)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT corePrint(printer);
}

void CoreInteraction::cutImage()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreCut();
}

void CoreInteraction::cutRegion(const QPoint &point)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreCutRegion(point);
}

void CoreInteraction::startChange(const QPoint &point)
{

    Q_EMIT coreStartChange(point);
}

void CoreInteraction::releasePos(const QPoint &point)
{
    Q_EMIT coreRealsePos(point);
}

void CoreInteraction::releaseCutChange(int type, const QPoint &point)
{
    Q_EMIT coreReleaseCutChange(type,point);
}

void CoreInteraction::exitCut()
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreExitCut();
}

void CoreInteraction::needSaveCutImage(int proportion)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreNeedSaveCutImage(proportion);
}

void CoreInteraction::needSaveAs(QString path)
{
    if (coreOperateTooOften()) {
        return;
    }
    Q_EMIT coreNeedSaveas(path);
}

void CoreInteraction::reloadImage(QModelIndex modelIndex)
{
    Q_EMIT coreReloadImage(modelIndex);
}


