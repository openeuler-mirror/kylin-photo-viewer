#ifndef NAVIGATOR_H
#define NAVIGATOR_H

#include <QWidget>
#include <QLabel>
#include <QPixmap>
#include <QDebug>
#include "controller/interaction.h"

class Navigator : public QWidget
{
    Q_OBJECT
public:
    explicit Navigator(QWidget *parent = nullptr);

private:
    QLabel *m_bottomImage;
    bool m_isPress = false;
    QPoint m_startPos = QPoint(-1,-1);
    QPoint m_endPos = QPoint(-1,-1);

    void showNavigation(QPixmap pix);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void getHighLightRegion(QPoint startPos,QPoint endPos);//拿起始点和终点



Q_SIGNALS:
    void naviChange();
    void posChange(QPoint pos);

};

#endif // NAVIGATOR_H
