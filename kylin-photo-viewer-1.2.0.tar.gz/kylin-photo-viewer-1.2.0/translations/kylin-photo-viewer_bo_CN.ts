<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>Core</name>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Information</name>
    <message>
        <source>Info</source>
        <translation>ཆ་འཕྲིན།</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>མིང་།</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>ཆེ་ཆུང་།</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>རིགས་གྲས་</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>ཁ་མདོག</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>བཅོས་པ།</translation>
    </message>
    <message>
        <source>Capacity</source>
        <translation>བགོ་སྐལ།</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>གསར་བཟོ་ས་</translation>
    </message>
</context>
<context>
    <name>KyView</name>
    <message>
        <source>full srceen</source>
        <translation>ཆེས་ཆེ་བ།</translation>
    </message>
    <message>
        <source>recovery</source>
        <translation>སླར་གསོ།</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>པར་རིས།།</translation>
    </message>
</context>
<context>
    <name>OpenImage</name>
    <message>
        <source>Open Image</source>
        <translation>པར་རིས།་ཁ་འབྱེད།(_O)</translation>
    </message>
    <message>
        <source>Image Files(</source>
        <translation>བརྙན་རིས་ཡིག་ཆ།</translation>
    </message>
    <message>
        <source>Load picture</source>
        <translation>པར་རིས་ཁུར་སྣོན།</translation>
    </message>
</context>
<context>
    <name>ShowImageWidget</name>
    <message>
        <source>Copy</source>
        <translation>འདྲ་ཕབ།</translation>
    </message>
    <message>
        <source>Set Desktop Wallpaper</source>
        <translation>འཆར་ངོས་ཀྱི་པར་རིས་སུ་བཀོད་པ།</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>པར་འདེབས།</translation>
    </message>
    <message>
        <source>Set Lock Wallpaper</source>
        <translation>འཆར་ངོས་ཀྱི་སྒྲོག་ངོས་པར་རིས་སུ་བཀོད་པ།</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>བསུབ་པ།</translation>
    </message>
    <message>
        <source>Show in File</source>
        <translation>ཡིག་ཁུག་ནང་མངོན་པ།</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>save fail.name cannot begin with &quot;.&quot; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>the file name is illegal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>是否保存对此图片的更改？</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TitleBar</name>
    <message>
        <source>minimize</source>
        <translation>ཆེས་ཆུང་འགྱུར།</translation>
    </message>
    <message>
        <source>close</source>
        <translation>ཁ་རྒྱག</translation>
    </message>
    <message>
        <source>full screen</source>
        <translation>ཆེས་ཆེ་བ།</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>པར་རིས།།</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This file will be hidden(the file whose name begins with &quot;.&quot; will be the hidden property file.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>the file name is illegal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File does not exist (or has been deleted)!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This name has been occupied, please choose another！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is a read-only file, please modify the permissions before operation！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other error, rename failed！</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBar</name>
    <message>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Life size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Window widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rorate right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sidebar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Get info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">བསུབ་པ།</translation>
    </message>
</context>
<context>
    <name>menuModule</name>
    <message>
        <source>Help</source>
        <translation>རོགས་རམ།</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>ཁ་འབྱེད།</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>ཕྱིར་འབུད།</translation>
    </message>
    <message>
        <source>menu</source>
        <translation>འདེམས་བྱང་།</translation>
    </message>
    <message>
        <source>About</source>
        <translation>འབྲེལ་ཡོད།</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>བརྗོད་གཞི།</translation>
    </message>
    <message>
        <source>close</source>
        <translation>ཁ་རྒྱག</translation>
    </message>
    <message>
        <source>Service &amp; Support Team: </source>
        <translation type="vanished">ཞབས་ཞུ་དང་རྒྱབ་སྐྱོར་ཁག</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation>པར་གཞི།：</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>པར་རིས།།</translation>
    </message>
    <message>
        <source>Service &amp; Support: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A system picture tool that can quickly open common formats. It provides zoom,flip and other processing simplely.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
